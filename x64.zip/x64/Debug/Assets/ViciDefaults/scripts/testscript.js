
function onUpdate() {
	//print("updating from javascript");
}

function onLoad() {
	print(`onLoad called from JS`)
}